package com.exa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdoptMascotasApplication {

	public static void main(String[] args) {
		SpringApplication.run(AdoptMascotasApplication.class, args);
	}

}
